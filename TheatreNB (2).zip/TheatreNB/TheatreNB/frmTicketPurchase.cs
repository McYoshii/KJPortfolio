﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheatreNB
{
    
    public partial class frmTicketPurchase : Form
    {
        public frmTicketPurchase()
        {
         
            InitializeComponent();
            
        }
        

    




        class Methods
    {

        

             

        }

        




        private void rdoBalcony_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void rdoOrchestra_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chk1979_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
           
           
        }

        public void btnClear_Click_1(object sender, EventArgs e)
        {
            txtCreditCard.Text = string.Empty;

            chk1979.Checked = false;
            chkAnnie.Checked = false;
            chkWonderfulLife.Checked = false;
            chkBoysGirls.Checked = false;

            

            rdoBalcony.Checked = true;
            rdoOrchestra.Checked = false;
            rdoBox.Checked = false;
          
        }

        public void frmTicketPurchase_Load_1(object sender, EventArgs e)
        {
            txtCreditCard.Text = string.Empty;

            chk1979.Checked = false;
            chkAnnie.Checked = false;
            chkWonderfulLife.Checked = false;
            chkBoysGirls.Checked = false;



            rdoBalcony.Checked = true;
            rdoOrchestra.Checked = false;
            rdoBox.Checked = false;
        }

        private void txtCreditCard_TextChanged(object sender, EventArgs e)
        {



            
        }

        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            
            if (txtCreditCard.TextLength == 0)
            {
                MessageBox.Show("Credit card is invalid");
                txtCreditCard.Text = string.Empty;
                txtCreditCard.Select();
            }

            else if (txtCreditCard.TextLength < 16)
            {
                MessageBox.Show("Credit card is invalid");
                txtCreditCard.Text = string.Empty;
                txtCreditCard.Select();
            }

            else if (txtCreditCard.TextLength > 16)
            {
                MessageBox.Show("Credit card is invalid");
                txtCreditCard.Text = string.Empty;
                txtCreditCard.Select(0, txtCreditCard.Text.Length);
            }

            else if (txtCreditCard.TextLength == 16)
            {
                MessageBox.Show("Thank you for your order!");
                txtCreditCard.Text = string.Empty;
                txtCreditCard.Select(0, txtCreditCard.Text.Length);
            }




            int counter = 0;
            if (chk1979.Checked == true)
            {
                counter++;

            }

            else if (chk1979.Checked == false)
            {
                counter--;
            }

            if (chkAnnie.Checked == true)
            {
                counter++;

            }

            else if (chkAnnie.Checked == false)
            {
                counter--;
            }

            if (chkWonderfulLife.Checked == true)
            {
                counter++;

            }

            else if (chkWonderfulLife.Checked == false)
            {
                counter--;
            }

            if (chkBoysGirls.Checked == true)
            {
                counter++;

            }

            else if (chkBoysGirls.Checked == false)
            {
                counter--;
            }








            double totalBalcony = 50 * counter;
            double totalOrchestra = 85 * counter;
            double totalBox = 110 * counter;

            


            

            if (rdoBalcony.Checked == true)
            {
                string lblDisplay = ("$" + totalBalcony + "has been charged to your credit card.");
            }

            if (rdoOrchestra.Checked == true)
            {
                string lblDisplay = ("$" + totalOrchestra + "has been charged to your credit card.");
            }

            if (rdoBox.Checked == true)
            {
                string lblDisplay = ("$" + totalBox + "has been charged to your credit card.");
            }







        }

        

        private void txtCreditCard_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (Char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Credit card is invalid");
                txtCreditCard.Text = "";
                txtCreditCard.Select();

            }

        }

        private void lblDisplay_Click(object sender, EventArgs e)
        {
            

            

            int counter = 0;
            if (chk1979.Checked == true)
            {
                counter++;

            }

            else if (chk1979.Checked == false)
            {
                counter--;
            }

            if (chkAnnie.Checked == true)
            {
                counter++;

            }

            else if (chkAnnie.Checked == false)
            {
                counter--;
            }

            if (chkWonderfulLife.Checked == true)
            {
                counter++;

            }

            else if (chkWonderfulLife.Checked == false)
            {
                counter--;
            }

            if (chkBoysGirls.Checked == true)
            {
                counter++;

            }

            else if (chkBoysGirls.Checked == false)
            {
                counter--;
            }




           




            
            double totalBalcony = 50 * counter;
            double totalOrchestra = 85 * counter;
            double totalBox = 110 * counter;

            

            if (rdoBalcony.Checked == true)
            {
                string lblDisplay = ("$" + totalBalcony + "has been charged to your credit card.");
            }

            if (rdoOrchestra.Checked == true)
            {
               string lblDisplay = ("$" + totalOrchestra + "has been charged to your credit card.");
            }

            if (rdoBox.Checked == true)
            {
                string lblDisplay = ("$" + totalBox + "has been charged to your credit card.");
            }

        }
}
}
