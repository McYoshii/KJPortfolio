﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PayCalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            

           

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textbox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textbox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double hoursWorked = Convert.ToDouble(textbox1.Text);
            double payRate = Convert.ToDouble(textbox2.Text);

            if (hoursWorked <= 40)
              {
                lblOvertimeHours.Text = "0"; 
              }

            

            else if (hoursWorked >= 40)
            {
                double overtimeHours = hoursWorked - 40;
            
                lblOvertimeHours.Text = overtimeHours.ToString();
            }


            //calculations
            if (hoursWorked <= 40)
            {
                double grossPay = hoursWorked * payRate;
                double tax = grossPay * 0.15;
                double netPay = grossPay - tax;

                string grossPayMsg = ("Your gross pay is $");
                string netPayMsg = (" \r\n Your net pay is $");
            


                //results
                 grossNetPay.Text = (grossPayMsg + grossPay) + (netPayMsg + netPay);

                //messageBox
                string message = ("Your gross pay is $" + grossPay) + (" \r\n Your net pay is $" + netPay);
                MessageBox.Show(message);
             }

            else if (hoursWorked >= 40) 
            {


                //divider
                double grossPay = 40 * payRate;
                double overtimeHours = hoursWorked - 40;
            
                double timeAndHalf = 1.5 * payRate;
                double overtimePay = overtimeHours * timeAndHalf;

                double tax = grossPay * 0.15;
                double netPay = grossPay - tax;
                

                string grossPayMsg = ("Your gross pay is $");
                string netPayMsg = (" \r\n Your net pay is $");
                //divider


                double grossPayHalf = overtimePay + grossPay;
                double newTax = (overtimePay + grossPay) * 0.15;
                double newNetPay = (overtimePay + grossPay) - newTax;


                //results2
                grossNetPay.Text = (grossPayMsg + grossPayHalf) + (netPayMsg + newNetPay);

                //messageBox2
                string message = ("Your gross pay is $" + grossPayHalf) + (" \r\n Your net pay is $" + newNetPay);
                MessageBox.Show(message);
            }






        }

        private void label5_Click_1(object sender, EventArgs e)
        {
           







        }

        private void button2_Click(object sender, EventArgs e)
        {
            

            textbox1.Text = "";
            textbox1.Text = string.Empty;

            textbox2.Text = "";
            textbox2.Text = string.Empty;

            lblOvertimeHours.Text = "";
            lblOvertimeHours.Text = string.Empty;

            grossNetPay.Text = "";
            grossNetPay.Text = string.Empty;

            textbox1.Select();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textbox1.Select();
            //Console.WriteLine(nameof(Form1)) = "The Pay Calculator";
        }
    }
}


