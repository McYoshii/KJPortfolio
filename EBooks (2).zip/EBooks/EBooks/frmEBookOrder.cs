﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EBooks
{
    public partial class frmEBookOrder : Form
    {
        private const decimal BOOK_PRICE = 19.99m;
        private const decimal EXPEDITED_SHIPPING_PRICE = 5.99m;

        public frmEBookOrder()
        {
            InitializeComponent();
        }


        #region Methods

        // YOU MUST PUT YOUR USER-DEFINED METHODS IN THIS REGION

        #endregion

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void cboAvailableBooks_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtQuantity.Text = "";
            lstCart.Text = "";
            lblSubtotal.Text = "";
            lblShipping.Text = "";
            lblTotal.Text = "";

            txtMemberNumber.Text = "";
            cboAvailableBooks.Text = "";

            chkExpedited.Checked = false;

            
        }

        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {
            




          


        }

        int count = 1;
        private void btnAddBook_Click(object sender, EventArgs e)
        {
            
            count++;
            if (txtQuantity != null)
            {
                txtQuantity.Text = count.ToString();
            }
        }



        private void btnCalculateOrder_Click(object sender, EventArgs e)
        {
            double subtotal = Convert.ToDouble(txtQuantity.Text);

            double sub = subtotal * 19.99;
            lblSubtotal.Text = sub.ToString();

            double grossPay = subtotal * 19.99;
            double shipping = grossPay ;
            double grossPay2 = grossPay + 5;
            lblSubtotal.Text = grossPay.ToString();

           
            

            lblSubtotal.Text = shipping.ToString();
            lblTotal.Text = grossPay2.ToString();

        }

        private void lblShipping_Click(object sender, EventArgs e)
        {
            if (chkExpedited.Checked == true) 
            {
            
                lblShipping.Text = "$5.00";




                double subtotal = Convert.ToDouble(txtQuantity.Text);

              

            }
            {
                 if (chkExpedited.Checked == false) 
                

                    lblShipping.Text = "$0.00";
                
            }
            

            

            
        }

        private void txtMemberNumber_TextChanged(object sender, EventArgs e)
        {
            
           
        }

        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            if (txtMemberNumber.TextLength < 6)
            {
                MessageBox.Show("Your member number is invalid");
                txtMemberNumber.Text = string.Empty;
                txtMemberNumber.Select();
            }

            else if (txtMemberNumber.TextLength > 6)
            {
                MessageBox.Show("Your member number is invalid");
                txtMemberNumber.Text = string.Empty;
                txtMemberNumber.Select(0, txtMemberNumber.Text.Length);
            }

            else if (txtMemberNumber.TextLength == 6)
            {
                MessageBox.Show("Thank you for your order!");
                txtMemberNumber.Text = string.Empty;
                txtMemberNumber.Select(0, txtMemberNumber.Text.Length);
            }
    }

        private void lblTotal_Click(object sender, EventArgs e)
        {

        }
    }
}

